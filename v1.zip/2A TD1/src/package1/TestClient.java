package package1;

public class TestClient {
	
	public static void main (String[] args) {
	
	Periodicite p = new Periodicite();
	Revue r = new Revue();
	Client c = new Client();
	
	c.ClientSuppr(1);

	}
	

}
